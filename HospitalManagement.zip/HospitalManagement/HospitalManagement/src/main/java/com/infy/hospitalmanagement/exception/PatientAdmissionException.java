package com.infy.hospitalmanagement.exception;

public class PatientAdmissionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientAdmissionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
