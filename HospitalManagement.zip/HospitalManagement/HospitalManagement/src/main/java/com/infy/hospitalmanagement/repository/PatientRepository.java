package com.infy.hospitalmanagement.repository;

public interface PatientRepository {

}
